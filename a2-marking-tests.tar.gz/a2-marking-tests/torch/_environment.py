def is_fbcode() -> bool:
    return False
